
<?php
/**
 * Plugin Name: Gerenciador de Links com Limite de Cliques
 * Description: Criação de slugs com links rotativos e limite de cliques por link.
 * Version: 1.0
 * Author: Ricardo Christovão
 * Author URI: https://christovao.com.br/wordpress/plugins/gerenciador-links
 * License: GPL2
 */

// Criação do menu no painel do WordPress
add_action('admin_menu', function() {
    add_menu_page(
        'Gerenciador de Links',        // Título da página
        'Links Manager',              // Título no menu
        'manage_options',             // Capacidade necessária
        'gerenciador_links',          // Slug único para o menu
        'gerenciador_links_dashboard',// Callback para renderizar a página
        'dashicons-admin-links'       // Ícone do menu
    );
});

// Callback para gerenciar painel de links
function gerenciador_links_dashboard() {
    global $wpdb;
    $table_name = $wpdb->prefix . 'gl_links';

    // Adicionar um novo link
    if ($_POST['action'] === 'add_link') {
        $slug = sanitize_title($_POST['slug']);
        $url = esc_url_raw($_POST['url']);
        $max_clicks = intval($_POST['max_clicks']);

        if ($slug && $url && $max_clicks) {
            $wpdb->insert($table_name, [
                'slug' => $slug,
                'url' => $url,
                'max_clicks' => $max_clicks,
                'clicks' => 0
            ]);
            echo '<div class="notice notice-success"><p>Link adicionado com sucesso!</p></div>';
        } else {
            echo '<div class="notice notice-error"><p>Erro ao adicionar o link.</p></div>';
        }
    }

    echo '<h1>Gerenciador de Links</h1>';
    echo '<form method="post">';
    echo '<input type="hidden" name="action" value="add_link" />';
    echo '<p>Slug: <input type="text" name="slug" required></p>';
    echo '<p>URL: <input type="url" name="url" required></p>';
    echo '<p>Limite de Cliques: <input type="number" name="max_clicks" required></p>';
    echo '<p><input type="submit" value="Adicionar Link"></p>';
    echo '</form>';

    // Mostrar tabela com links cadastrados
    $links = $wpdb->get_results("SELECT * FROM $table_name");
    echo '<h2>Links Cadastrados</h2>';
    if ($links) {
        echo '<table border="1" cellpadding="10">';
        echo '<tr><th>Slug</th><th>URL</th><th>Cliques</th><th>Limite</th></tr>';
        foreach ($links as $link) {
            echo "<tr>
                <td>" . esc_html($link->slug) . "</td>
                <td>" . esc_url($link->url) . "</td>
                <td>" . intval($link->clicks) . "</td>
                <td>" . intval($link->max_clicks) . "</td>
            </tr>";
        }
        echo '</table>';
    } else {
        echo '<p>Nenhum link cadastrado.</p>';
    }
}

// Criação da tabela no banco de dados
register_activation_hook(__FILE__, function() {
    global $wpdb;
    $table_name = $wpdb->prefix . 'gl_links';
    $charset_collate = $wpdb->get_charset_collate();

    $sql = "CREATE TABLE $table_name (
        id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
        slug VARCHAR(255) NOT NULL,
        url TEXT NOT NULL,
        max_clicks BIGINT(20) NOT NULL,
        clicks BIGINT(20) DEFAULT 0,
        PRIMARY KEY (id)
    ) $charset_collate;";

    require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
    dbDelta($sql);
});

// Redirecionamento baseado no slug
add_action('template_redirect', function() {
    global $wpdb;

    // Recupera o slug da URL
    $slug = get_query_var('pagename');
    $links_table = $wpdb->prefix . 'gl_links';

    // Busca links válidos do slug
    $link = $wpdb->get_row($wpdb->prepare("SELECT * FROM $links_table WHERE slug = %s AND clicks < max_clicks", $slug));

    if ($link) {
        // Atualiza contador de cliques
        $wpdb->update($links_table, ['clicks' => $link->clicks + 1], ['id' => $link->id]);
        wp_redirect($link->url);
        exit;
    } elseif ($slug) {
        // Slug não encontrado ou esgotado
        wp_die('Todos os links associados a este slug estão esgotados.');
    }
});

// Define query_var custom para slugs
add_filter('query_vars', function($vars) {
    $vars[] = 'pagename';
    return $vars;
});
?>

