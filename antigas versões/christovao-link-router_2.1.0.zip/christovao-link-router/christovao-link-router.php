<?php
/**
 * Plugin Name:       Gerenciador de Links Avançado
 * Description:       Criação de slugs com links rotativos, limite de cliques e fallback configurável por slug.
 * Version:           2.1.0
 * Author:            Ricardo Christovão
 * Author URI:        https://christovao.com.br/wordpress/plugins/gerenciador-links
 * License:           GPL2
 */

// Evita o acesso direto ao arquivo
if (!defined('ABSPATH')) {
    exit;
}

// Nomes das tabelas
global $wpdb;
define('GL_TABLE_SLUGS', $wpdb->prefix . 'gl_slugs');
define('GL_TABLE_LINKS', $wpdb->prefix . 'gl_links');

// Criação/Atualização das tabelas na ativação do plugin
register_activation_hook(__FILE__, function() {
    global $wpdb;
    $charset_collate = $wpdb->get_charset_collate();
    require_once(ABSPATH . 'wp-admin/includes/upgrade.php');

    // Tabela para os Slugs
    $sql_slugs = "CREATE TABLE " . GL_TABLE_SLUGS . " (
        id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
        slug_name VARCHAR(255) NOT NULL,
        fallback_page_id BIGINT(20) UNSIGNED DEFAULT 0,
        PRIMARY KEY (id),
        UNIQUE KEY slug_name (slug_name)
    ) $charset_collate;";
    dbDelta($sql_slugs);

    // Tabela para os Links associados aos Slugs
    $sql_links = "CREATE TABLE " . GL_TABLE_LINKS . " (
        id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
        slug_id BIGINT(20) UNSIGNED NOT NULL,
        url TEXT NOT NULL,
        max_clicks BIGINT(20) NOT NULL,
        clicks BIGINT(20) DEFAULT 0,
        PRIMARY KEY (id),
        KEY slug_id (slug_id)
    ) $charset_collate;";
    dbDelta($sql_links);
});

// Adiciona o menu ao painel administrativo
add_action('admin_menu', function() {
    add_menu_page(
        'Gerenciador de Links',
        'Gerenciador Links',
        'manage_options',
        'gerenciador_links',
        'gl_render_admin_page',
        'dashicons-admin-links'
    );
});

/**
 * Processa todas as ações de formulário ANTES da página ser renderizada
 */
function gl_handle_actions() {
    global $wpdb;

    // Se não houver nenhuma ação, sai da função
    if (!isset($_REQUEST['action'])) {
        return;
    }

    // Processa a ação de acordo com o que foi solicitado
    switch ($_REQUEST['action']) {

        case 'add_link':
            check_admin_referer('gl_add_link_action', 'gl_add_link_nonce');

            $slug_name = sanitize_title($_POST['slug_name']);
            $url = esc_url_raw($_POST['url']);
            $max_clicks = intval($_POST['max_clicks']);
            $fallback_page_id = isset($_POST['fallback_page_id']) ? intval($_POST['fallback_page_id']) : 0;

            if ($slug_name && $url && $max_clicks > 0) {
                // Verifica se o slug já existe, senão, cria.
                $slug_id = $wpdb->get_var($wpdb->prepare("SELECT id FROM " . GL_TABLE_SLUGS . " WHERE slug_name = %s", $slug_name));

                if (!$slug_id) {
                    $wpdb->insert(GL_TABLE_SLUGS, ['slug_name' => $slug_name, 'fallback_page_id' => $fallback_page_id]);
                    $slug_id = $wpdb->insert_id;
                }

                // Insere o novo link associado ao slug
                $wpdb->insert(GL_TABLE_LINKS, ['slug_id' => $slug_id, 'url' => $url, 'max_clicks' => $max_clicks]);
                wp_redirect(admin_url('admin.php?page=gerenciador_links&gl_notice=add_success'));
                exit;
            } else {
                wp_redirect(admin_url('admin.php?page=gerenciador_links&gl_notice=add_error'));
                exit;
            }
            break;

        case 'update_slug':
            check_admin_referer('gl_edit_slug_' . $_POST['slug_id']);
            
            $slug_id = intval($_POST['slug_id']);
            $fallback_page_id = intval($_POST['fallback_page_id']);
            
            $wpdb->update(GL_TABLE_SLUGS, ['fallback_page_id' => $fallback_page_id], ['id' => $slug_id]);
            wp_redirect(admin_url('admin.php?page=gerenciador_links&gl_notice=update_success'));
            exit;
            break;

        case 'reset':
            check_admin_referer('gl_reset_link_' . $_GET['link_id']);

            $link_id = intval($_GET['link_id']);
            $wpdb->update(GL_TABLE_LINKS, ['clicks' => 0], ['id' => $link_id]);
            wp_redirect(admin_url('admin.php?page=gerenciador_links&gl_notice=reset_success'));
            exit;
            break;

        case 'delete':
            check_admin_referer('gl_delete_link_' . $_GET['link_id']);
            
            $link_id = intval($_GET['link_id']);
            $wpdb->delete(GL_TABLE_LINKS, ['id' => $link_id]);
            wp_redirect(admin_url('admin.php?page=gerenciador_links&gl_notice=delete_success'));
            exit;
            break;
    }
}
// Gancho para processar as ações antes de carregar o cabeçalho da página admin
add_action('admin_init', 'gl_handle_actions');


/**
 * Renderiza a página de administração
 */
function gl_render_admin_page() {
    global $wpdb;

    // Exibe notificações de sucesso/erro
    if (isset($_GET['gl_notice'])) {
        $messages = [
            'add_success' => 'Link adicionado com sucesso!',
            'add_error' => 'Erro ao adicionar o link. Verifique todos os campos.',
            'update_success' => 'Página de fallback atualizada com sucesso!',
            'reset_success' => 'Cliques do link resetados!',
            'delete_success' => 'Link deletado com sucesso!',
        ];
        $notice_type = strpos($_GET['gl_notice'], 'error') !== false ? 'error' : 'success';
        echo '<div id="message" class="notice notice-'.esc_attr($notice_type).' is-dismissible"><p>'.esc_html($messages[$_GET['gl_notice']]).'</p></div>';
    }

    $editing_slug_id = (isset($_GET['action']) && $_GET['action'] === 'edit_slug') ? intval($_GET['slug_id']) : 0;
    
    ?>
    <div class="wrap">
        <h1><span class="dashicons-before dashicons-admin-links"></span> Gerenciador de Links</h1>

        <?php if ($editing_slug_id) : 
            $slug_to_edit = $wpdb->get_row($wpdb->prepare("SELECT * FROM " . GL_TABLE_SLUGS . " WHERE id = %d", $editing_slug_id));
        ?>
            <h2>Editando Fallback do Slug: <?php echo esc_html($slug_to_edit->slug_name); ?></h2>
            <form method="POST" action="<?php echo admin_url('admin.php'); ?>">
                <input type="hidden" name="action" value="update_slug">
                <input type="hidden" name="slug_id" value="<?php echo $editing_slug_id; ?>">
                <?php wp_nonce_field('gl_edit_slug_' . $editing_slug_id); ?>
                <table class="form-table">
                    <tr valign="top">
                        <th scope="row"><label for="fallback_page_id">Página de Fallback</label></th>
                        <td>
                            <?php wp_dropdown_pages([
                                'name' => 'fallback_page_id',
                                'selected' => $slug_to_edit->fallback_page_id,
                                'show_option_none' => 'Nenhuma (Padrão)',
                                'option_none_value' => '0'
                            ]); ?>
                            <p class="description">Esta página será exibida quando todos os links deste slug esgotarem os cliques.</p>
                        </td>
                    </tr>
                </table>
                <?php submit_button('Salvar Alterações'); ?>
                 <a href="?page=gerenciador_links" class="button">Voltar</a>
            </form>
        <?php else : ?>
            <div id="col-container" class="wp-clearfix">
                <div id="col-left">
                    <div class="col-wrap">
                        <h2>Adicionar Novo Link</h2>
                        <form method="POST" action="<?php echo admin_url('admin.php'); ?>">
                            <input type="hidden" name="action" value="add_link">
                            <?php wp_nonce_field('gl_add_link_action', 'gl_add_link_nonce'); ?>
                            <div class="form-field">
                                <label for="slug_name">Nome do Slug</label>
                                <input type="text" name="slug_name" id="slug_name" required>
                                <p>Caminho do link (ex: `promo-dia-das-maes`). Se o slug não existir, ele será criado.</p>
                            </div>
                            <div class="form-field">
                                <label for="url">URL de Destino</label>
                                <input type="url" name="url" id="url" required>
                                <p>O link para onde o usuário será redirecionado.</p>
                            </div>
                            <div class="form-field">
                                <label for="max_clicks">Limite de Cliques</label>
                                <input type="number" name="max_clicks" id="max_clicks" value="100" min="1" required>
                                <p>Número máximo de cliques para este link específico.</p>
                            </div>
                            <div class="form-field">
                                <label for="fallback_page_id">Página de Fallback</label>
                                <?php wp_dropdown_pages(['name' => 'fallback_page_id', 'show_option_none' => 'Nenhuma (Padrão)', 'option_none_value' => '0']); ?>
                                <p>Esta opção só é aplicada ao <strong>criar um novo slug</strong>. Para editar um existente, use o botão "Editar Fallback".</p>
                            </div>
                            <?php submit_button('Adicionar Link', 'primary'); ?>
                        </form>
                    </div>
                </div>
                <div id="col-right">
                    <div class="col-wrap">
                        <h2>Slugs e Links Atuais</h2>
                        <?php
                        $slugs = $wpdb->get_results("SELECT * FROM " . GL_TABLE_SLUGS . " ORDER BY slug_name ASC");

                        if ($slugs) {
                            foreach ($slugs as $slug) {
                                $edit_url = admin_url('admin.php?page=gerenciador_links&action=edit_slug&slug_id=' . $slug->id);
                                $fallback_title = $slug->fallback_page_id ? get_the_title($slug->fallback_page_id) : 'Nenhuma';
                                ?>
                                <div class="slug-group">
                                    <h3>
                                        Slug: /<?php echo esc_html($slug->slug_name); ?>/
                                        <a href="<?php echo esc_url($edit_url); ?>" class="page-title-action">Editar Fallback</a>
                                    </h3>
                                    <p><strong>Página de Fallback:</strong> <?php echo esc_html($fallback_title); ?></p>
                                    
                                    <table class="wp-list-table widefat striped">
                                        <thead><tr><th>URL de Destino</th><th>Progresso Cliques</th><th>Ações</th></tr></thead>
                                        <tbody>
                                            <?php
                                            $links = $wpdb->get_results($wpdb->prepare("SELECT * FROM " . GL_TABLE_LINKS . " WHERE slug_id = %d", $slug->id));
                                            if ($links) {
                                                foreach ($links as $link) {
                                                    $reset_url = wp_nonce_url(admin_url('admin.php?page=gerenciador_links&action=reset&link_id=' . $link->id), 'gl_reset_link_' . $link->id);
                                                    $delete_url = wp_nonce_url(admin_url('admin.php?page=gerenciador_links&action=delete&link_id=' . $link->id), 'gl_delete_link_' . $link->id);
                                                    $progress = ($link->max_clicks > 0) ? ($link->clicks / $link->max_clicks) * 100 : 0;
                                                    ?>
                                                    <tr>
                                                        <td><?php echo esc_url($link->url); ?></td>
                                                        <td>
                                                            <progress value="<?php echo $link->clicks; ?>" max="<?php echo $link->max_clicks; ?>" title="<?php printf('%.1f%%', $progress); ?>"></progress>
                                                            <?php echo intval($link->clicks); ?> / <?php echo intval($link->max_clicks); ?>
                                                        </td>
                                                        <td>
                                                            <a href="<?php echo esc_url($reset_url); ?>" onclick="return confirm('Tem certeza que deseja resetar os cliques?');">Resetar</a> | 
                                                            <a href="<?php echo esc_url($delete_url); ?>" onclick="return confirm('Tem certeza que deseja deletar este link?');" style="color:#a00;">Deletar</a>
                                                        </td>
                                                    </tr>
                                                    <?php
                                                }
                                            } else {
                                                echo '<tr><td colspan="3">Nenhum link associado a este slug.</td></tr>';
                                            }
                                            ?>
                                        </tbody>
                                    </table>
                                </div>
                                <?php
                            }
                        } else {
                            echo '<p>Nenhum slug cadastrado ainda. Comece adicionando um link no formulário ao lado.</p>';
                        }
                        ?>
                    </div>
                </div>
            </div>
        <?php endif; ?>
    </div>
    <style>
        .slug-group { margin-bottom: 2em; padding: 1em; background: #fff; border: 1px solid #ddd; border-radius: 4px;}
        .slug-group h3 { margin-top: 0; padding-bottom: 0.5em; border-bottom: 1px solid #eee; }
        .form-field { margin-bottom: 1rem; }
        .form-field label { display: inline-block; width: 100%; margin-bottom: 5px; font-weight: 600; }
        .form-field input[type="text"], .form-field input[type="url"], .form-field input[type="number"], .form-field select { width: 100%; }
        progress { width: 100%; }
    </style>
    <?php
}

// Lógica de Redirecionamento
add_action('init', function() {
    global $wpdb;

    $request_uri = trim(parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH), '/');
    
    if (empty($request_uri) || strpos($request_uri, 'wp-admin') === 0 || strpos($request_uri, 'wp-login') === 0) {
        return;
    }

    $slug = $wpdb->get_row($wpdb->prepare("SELECT * FROM " . GL_TABLE_SLUGS . " WHERE slug_name = %s", $request_uri));
    
    if (!$slug) {
        return;
    }

    $active_link = $wpdb->get_row($wpdb->prepare(
        "SELECT * FROM " . GL_TABLE_LINKS . " WHERE slug_id = %d AND clicks < max_clicks ORDER BY id ASC LIMIT 1",
        $slug->id
    ));

    if ($active_link) {
        $wpdb->update(
            GL_TABLE_LINKS,
            ['clicks' => $active_link->clicks + 1],
            ['id' => $active_link->id]
        );

        wp_redirect($active_link->url, 302);
        exit;
    } 
    else {
        if ($slug->fallback_page_id > 0 && get_post_status($slug->fallback_page_id) === 'publish') {
            wp_redirect(get_permalink($slug->fallback_page_id), 302);
            exit;
        } else {
            wp_die(
                'Desculpe, todos os links para este destino foram esgotados e não há uma página de fallback configurada.', 
                'Links Esgotados', 
                ['response' => 404]
            );
        }
    }
});