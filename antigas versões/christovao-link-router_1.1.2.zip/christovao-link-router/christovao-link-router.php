
<?php
/**
 * Plugin Name: Gerenciador de Links com Limite de Cliques
 * Description: Criação de slugs com links rotativos e limite de cliques por link.
 * Version: 1.1.2
 * Author: Ricardo Christovão
 * Author URI: https://christovao.com.br/wordpress/plugins/gerenciador-links
 * License: GPL2
 */

// Atualização para criar ou corrigir a tabela ao ativar o plugin
register_activation_hook(__FILE__, function() {
    global $wpdb;
    $table_name = $wpdb->prefix . 'gl_links';

    $charset_collate = $wpdb->get_charset_collate();

    $sql = "CREATE TABLE $table_name (
        id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
        slug VARCHAR(255) NOT NULL,
        url TEXT NOT NULL,
        max_clicks BIGINT(20) NOT NULL,
        clicks BIGINT(20) DEFAULT 0,
        fallback_page_id BIGINT(20) DEFAULT NULL,
        PRIMARY KEY (id)
    ) $charset_collate;";

    require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
    dbDelta($sql);
});

// Adicionar menu no painel do WordPress
add_action('admin_menu', function() {
    add_menu_page(
        'Gerenciador de Slugs',
        'Slugs Manager',
        'manage_options',
        'gerenciador_slugs',
        'gl_render_admin_dashboard',
        'dashicons-networking'
    );
});

// Renderizar o painel de administração
function gl_render_admin_dashboard() {
    global $wpdb;
    $table_name = $wpdb->prefix . 'gl_links';

    // Lógica para adicionar links
    if ($_POST['action'] === 'add_link') {
        $slug = sanitize_text_field($_POST['slug']);
        $url = esc_url_raw($_POST['url']);
        $max_clicks = intval($_POST['max_clicks']);
        $fallback_page_id = intval($_POST['fallback_page_id']);

        if ($slug && $url && $max_clicks > 0) {
            $wpdb->insert($table_name, [
                'slug' => $slug,
                'url' => $url,
                'max_clicks' => $max_clicks,
                'clicks' => 0,
                'fallback_page_id' => $fallback_page_id
            ]);
            echo '<div class="notice notice-success"><p>Link adicionado ao slug ' . esc_html($slug) . ' com sucesso!</p></div>';
        } else {
            echo '<div class="notice notice-error"><p>Erro ao adicionar o link. Verifique os dados.</p></div>';
        }
    }

    // Formulário para adicionar novo link
    echo '<h1>Gerenciador de Slugs</h1>';
    echo '<form method="POST">';
    echo '<input type="hidden" name="action" value="add_link">';
    echo '<p>Slug: <input type="text" name="slug" required></p>';
    echo '<p>URL: <input type="url" name="url" required></p>';
    echo '<p>Limite de Cliques: <input type="number" name="max_clicks" required></p>';
    echo '<p>Fallback Page: ';
    wp_dropdown_pages(['name' => 'fallback_page_id', 'show_option_none' => 'Nenhuma página']);
    echo '</p>';
    echo '<p><input type="submit" value="Adicionar Link"></p>';
    echo '</form>';

    // Exibição de links agrupados por slug
    $slugs = $wpdb->get_results("SELECT DISTINCT slug FROM $table_name");

    if ($slugs) {
        echo '<h2>Slugs e Links</h2>';

        foreach ($slugs as $slug_row) {
            $slug = $slug_row->slug;
            $links = $wpdb->get_results($wpdb->prepare("SELECT * FROM $table_name WHERE slug = %s", $slug));

            echo '<h3>Slug: ' . esc_html($slug) . '</h3>';
            echo '<table border="1" cellpadding="5">';
            echo '<tr><th>URL</th><th>Cliques</th><th>Limite</th><th>Fallback</th><th>Ações</th></tr>';

            foreach ($links as $link) {
                echo '<tr>';
                echo '<td>' . esc_url($link->url) . '</td>';
                echo '<td>' . intval($link->clicks) . '</td>';
                echo '<td>' . intval($link->max_clicks) . '</td>';
                echo '<td>' . ($link->fallback_page_id ? get_the_title($link->fallback_page_id) : 'Nenhuma') . '</td>';
                echo '<td>
                    <form method="POST" style="display:inline;">
                        <input type="hidden" name="action" value="reset_clicks">
                        <input type="hidden" name="link_id" value="' . intval($link->id) . '">
                        <input type="submit" value="Resetar Cliques">
                    </form>
                </td>';
                echo '</tr>';
            }

            echo '</table>';
        }
    } else {
        echo '<p>Nenhum link cadastrado ainda.</p>';
    }
}

// Redirecionamento com fallback para páginas de Slugs agrupados
add_action('template_redirect', function() {
    global $wpdb;

    $slug = get_query_var('pagename');
    $table_name = $wpdb->prefix . 'gl_links';

    $links = $wpdb->get_results($wpdb->prepare(
        "SELECT * FROM $table_name WHERE slug = %s", 
        $slug
    ));

    $active_link = null;
    foreach ($links as $link) {
        if ($link->clicks < $link->max_clicks) {
            $active_link = $link;
            break;
        }
    }

    if ($active_link) {
        $wpdb->update(
            $table_name,
            ['clicks' => $active_link->clicks + 1],
            ['id' => $active_link->id]
        );
        wp_redirect($active_link->url);
        exit;
    } else {
        $fallback_page_id = $links[0]->fallback_page_id ?? null;

        if ($fallback_page_id) {
            wp_redirect(get_permalink($fallback_page_id));
            exit;
        } else {
            wp_die('Todos os links associados a este slug foram esgotados.');
        }
    }
});
?>