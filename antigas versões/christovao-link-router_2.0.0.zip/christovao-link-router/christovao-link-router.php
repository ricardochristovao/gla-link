<?php
/**
 * Plugin Name:       Gerenciador de Links Avançado
 * Description:       Criação de slugs com links rotativos, limite de cliques e fallback configurável por slug.
 * Version:           2.0.0
 * Author:            Ricardo Christovão
 * Author URI:        https://christovao.com.br/wordpress/plugins/gerenciador-links
 * License:           GPL2
 */

// Evita o acesso direto ao arquivo
if (!defined('ABSPATH')) {
    exit;
}

// Nomes das tabelas
global $wpdb;
define('GL_TABLE_SLUGS', $wpdb->prefix . 'gl_slugs');
define('GL_TABLE_LINKS', $wpdb->prefix . 'gl_links');

// Criação/Atualização das tabelas na ativação do plugin
register_activation_hook(__FILE__, function() {
    global $wpdb;
    $charset_collate = $wpdb->get_charset_collate();
    require_once(ABSPATH . 'wp-admin/includes/upgrade.php');

    // Tabela para os Slugs
    $sql_slugs = "CREATE TABLE " . GL_TABLE_SLUGS . " (
        id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
        slug_name VARCHAR(255) NOT NULL,
        fallback_page_id BIGINT(20) UNSIGNED DEFAULT 0,
        PRIMARY KEY (id),
        UNIQUE KEY slug_name (slug_name)
    ) $charset_collate;";
    dbDelta($sql_slugs);

    // Tabela para os Links associados aos Slugs
    $sql_links = "CREATE TABLE " . GL_TABLE_LINKS . " (
        id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
        slug_id BIGINT(20) UNSIGNED NOT NULL,
        url TEXT NOT NULL,
        max_clicks BIGINT(20) NOT NULL,
        clicks BIGINT(20) DEFAULT 0,
        PRIMARY KEY (id),
        KEY slug_id (slug_id)
    ) $charset_collate;";
    dbDelta($sql_links);
});

// Adiciona o menu ao painel administrativo
add_action('admin_menu', function() {
    add_menu_page(
        'Gerenciador de Links',
        'Gerenciador Links',
        'manage_options',
        'gerenciador_links',
        'gl_render_admin_page',
        'dashicons-admin-links'
    );
});

/**
 * Processa todas as ações de formulário (Adicionar, Editar, Deletar, Resetar)
 */
function gl_handle_form_actions() {
    global $wpdb;

    if (!isset($_POST['gl_action_nonce']) || !wp_verify_nonce($_POST['gl_action_nonce'], 'gl_action')) {
        return; // Falha na verificação de segurança
    }

    // Ação: Adicionar um novo link
    if (isset($_POST['action']) && $_POST['action'] === 'add_link') {
        $slug_name = sanitize_title($_POST['slug_name']);
        $url = esc_url_raw($_POST['url']);
        $max_clicks = intval($_POST['max_clicks']);
        $fallback_page_id = isset($_POST['fallback_page_id']) ? intval($_POST['fallback_page_id']) : 0;

        if ($slug_name && $url && $max_clicks > 0) {
            // Verifica se o slug já existe, senão, cria.
            $slug_id = $wpdb->get_var($wpdb->prepare("SELECT id FROM " . GL_TABLE_SLUGS . " WHERE slug_name = %s", $slug_name));

            if (!$slug_id) {
                $wpdb->insert(GL_TABLE_SLUGS, [
                    'slug_name' => $slug_name,
                    'fallback_page_id' => $fallback_page_id
                ]);
                $slug_id = $wpdb->insert_id;
            }

            // Insere o novo link associado ao slug
            $wpdb->insert(GL_TABLE_LINKS, [
                'slug_id' => $slug_id,
                'url' => $url,
                'max_clicks' => $max_clicks,
            ]);
            
            echo '<div id="message" class="notice notice-success is-dismissible"><p>Link adicionado com sucesso ao slug <strong>' . esc_html($slug_name) . '</strong>!</p></div>';
        } else {
            echo '<div id="message" class="notice notice-error is-dismissible"><p>Erro ao adicionar o link. Verifique todos os campos.</p></div>';
        }
    }

    // Ação: Atualizar o fallback de um slug
    if (isset($_POST['action']) && $_POST['action'] === 'update_slug') {
        $slug_id = intval($_POST['slug_id']);
        $fallback_page_id = intval($_POST['fallback_page_id']);
        
        $wpdb->update(
            GL_TABLE_SLUGS,
            ['fallback_page_id' => $fallback_page_id],
            ['id' => $slug_id]
        );
        echo '<div id="message" class="notice notice-success is-dismissible"><p>Página de fallback atualizada com sucesso!</p></div>';
    }

    // Ação: Resetar cliques de um link
    if (isset($_GET['action']) && $_GET['action'] === 'reset') {
        $link_id = intval($_GET['link_id']);
        $wpdb->update(GL_TABLE_LINKS, ['clicks' => 0], ['id' => $link_id]);
        echo '<div id="message" class="notice notice-success is-dismissible"><p>Cliques do link resetados!</p></div>';
    }

    // Ação: Deletar um link
    if (isset($_GET['action']) && $_GET['action'] === 'delete') {
        $link_id = intval($_GET['link_id']);
        $wpdb->delete(GL_TABLE_LINKS, ['id' => $link_id]);
        echo '<div id="message" class="notice notice-success is-dismissible"><p>Link deletado com sucesso!</p></div>';
    }
}

/**
 * Renderiza a página de administração
 */
function gl_render_admin_page() {
    global $wpdb;
    
    // Primeiro, processa qualquer ação de formulário que tenha sido enviada.
    gl_handle_form_actions();

    // Verifica se estamos na página de edição de um slug
    $editing_slug_id = (isset($_GET['action']) && $_GET['action'] === 'edit_slug') ? intval($_GET['slug_id']) : 0;
    
    ?>
    <div class="wrap">
        <h1><span class="dashicons-before dashicons-admin-links"></span> Gerenciador de Links</h1>

        <?php if ($editing_slug_id) : 
            $slug_to_edit = $wpdb->get_row($wpdb->prepare("SELECT * FROM " . GL_TABLE_SLUGS . " WHERE id = %d", $editing_slug_id));
        ?>
            <h2>Editando Fallback do Slug: <?php echo esc_html($slug_to_edit->slug_name); ?></h2>
            <form method="POST" action="">
                <input type="hidden" name="action" value="update_slug">
                <input type="hidden" name="slug_id" value="<?php echo $editing_slug_id; ?>">
                <?php wp_nonce_field('gl_action', 'gl_action_nonce'); ?>
                <table class="form-table">
                    <tr valign="top">
                        <th scope="row"><label for="fallback_page_id">Página de Fallback</label></th>
                        <td>
                            <?php wp_dropdown_pages([
                                'name' => 'fallback_page_id',
                                'selected' => $slug_to_edit->fallback_page_id,
                                'show_option_none' => 'Nenhuma (Padrão)',
                                'option_none_value' => '0'
                            ]); ?>
                            <p class="description">Esta página será exibida quando todos os links deste slug esgotarem os cliques.</p>
                        </td>
                    </tr>
                </table>
                <?php submit_button('Salvar Alterações'); ?>
                 <a href="?page=gerenciador_links" class="button">Voltar</a>
            </form>
        <?php else : ?>
            <div id="col-container" class="wp-clearfix">
                <div id="col-left">
                    <div class="col-wrap">
                        <h2>Adicionar Novo Link a um Slug</h2>
                        <form method="POST" action="">
                            <input type="hidden" name="action" value="add_link">
                            <?php wp_nonce_field('gl_action', 'gl_action_nonce'); ?>
                            <div class="form-field">
                                <label for="slug_name">Nome do Slug</label>
                                <input type="text" name="slug_name" id="slug_name" required>
                                <p>Caminho do link (ex: `meu-produto`). Se o slug não existir, ele será criado.</p>
                            </div>
                            <div class="form-field">
                                <label for="url">URL de Destino</label>
                                <input type="url" name="url" id="url" required>
                                <p>O link para onde o usuário será redirecionado.</p>
                            </div>
                            <div class="form-field">
                                <label for="max_clicks">Limite de Cliques</label>
                                <input type="number" name="max_clicks" id="max_clicks" value="100" min="1" required>
                                <p>Número máximo de cliques para este link específico.</p>
                            </div>
                            <div class="form-field">
                                <label for="fallback_page_id">Página de Fallback (para slugs novos)</label>
                                <?php wp_dropdown_pages(['name' => 'fallback_page_id', 'show_option_none' => 'Nenhuma (Padrão)']); ?>
                                <p>Se estiver criando um novo slug, defina a página de fallback aqui. Para slugs existentes, use a opção "Editar".</p>
                            </div>
                            <?php submit_button('Adicionar Link', 'primary'); ?>
                        </form>
                    </div>
                </div>
                <div id="col-right">
                    <div class="col-wrap">
                        <h2>Slugs e Links Atuais</h2>
                        <?php
                        $slugs = $wpdb->get_results("SELECT * FROM " . GL_TABLE_SLUGS . " ORDER BY slug_name ASC");

                        if ($slugs) {
                            foreach ($slugs as $slug) {
                                $fallback_title = $slug->fallback_page_id ? get_the_title($slug->fallback_page_id) : 'Nenhuma';
                                ?>
                                <div class="slug-group">
                                    <h3>
                                        Slug: /<?php echo esc_html($slug->slug_name); ?>/
                                        <a href="?page=gerenciador_links&action=edit_slug&slug_id=<?php echo $slug->id; ?>" class="page-title-action">Editar Fallback</a>
                                    </h3>
                                    <p><strong>Fallback:</strong> <?php echo esc_html($fallback_title); ?></p>
                                    
                                    <table class="wp-list-table widefat striped">
                                        <thead>
                                            <tr>
                                                <th>URL de Destino</th>
                                                <th>Progresso Cliques</th>
                                                <th>Ações</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php
                                            $links = $wpdb->get_results($wpdb->prepare("SELECT * FROM " . GL_TABLE_LINKS . " WHERE slug_id = %d", $slug->id));
                                            if ($links) {
                                                foreach ($links as $link) {
                                                    $progress = ($link->clicks / $link->max_clicks) * 100;
                                                    ?>
                                                    <tr>
                                                        <td><?php echo esc_url($link->url); ?></td>
                                                        <td>
                                                            <progress value="<?php echo $link->clicks; ?>" max="<?php echo $link->max_clicks; ?>" title="<?php printf('%.2f%%', $progress); ?>"></progress>
                                                            <?php echo intval($link->clicks); ?> / <?php echo intval($link->max_clicks); ?>
                                                        </td>
                                                        <td>
                                                            <a href="?page=gerenciador_links&action=reset&link_id=<?php echo $link->id; ?>&gl_action_nonce=<?php echo wp_create_nonce('gl_action'); ?>" onclick="return confirm('Tem certeza que deseja resetar os cliques?');">Resetar</a> | 
                                                            <a href="?page=gerenciador_links&action=delete&link_id=<?php echo $link->id; ?>&gl_action_nonce=<?php echo wp_create_nonce('gl_action'); ?>" onclick="return confirm('Tem certeza que deseja deletar este link?');" style="color:#a00;">Deletar</a>
                                                        </td>
                                                    </tr>
                                                    <?php
                                                }
                                            } else {
                                                echo '<tr><td colspan="3">Nenhum link associado a este slug.</td></tr>';
                                            }
                                            ?>
                                        </tbody>
                                    </table>
                                </div>
                                <?php
                            }
                        } else {
                            echo '<p>Nenhum slug cadastrado ainda. Comece adicionando um link no formulário ao lado.</p>';
                        }
                        ?>
                    </div>
                </div>
            </div>
        <?php endif; ?>
    </div>
    <style>
        .slug-group { margin-bottom: 2em; padding: 1em; background: #fff; border: 1px solid #ddd; }
        .slug-group h3 { margin-top: 0; padding-bottom: 0.5em; border-bottom: 1px solid #eee; }
        .form-field { margin-bottom: 1rem; }
        .form-field label { display: inline-block; width: 100%; margin-bottom: 5px; }
        .form-field input[type="text"], .form-field input[type="url"], .form-field input[type="number"], .form-field select { width: 100%; }
        progress { width: 100%; }
    </style>
    <?php
}

// Lógica de Redirecionamento
add_action('init', function() {
    global $wpdb;

    // Pega o caminho da URL solicitada (ex: /meu-produto/) e limpa
    $request_uri = trim(parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH), '/');
    
    if (empty($request_uri)) {
        return;
    }

    // 1. Encontra o slug no nosso banco de dados
    $slug = $wpdb->get_row($wpdb->prepare("SELECT * FROM " . GL_TABLE_SLUGS . " WHERE slug_name = %s", $request_uri));
    
    if (!$slug) {
        return; // Se não for um dos nossos slugs, o WordPress continua o carregamento normal
    }

    // 2. Encontra um link ativo para este slug (que ainda não atingiu o limite)
    $active_link = $wpdb->get_row($wpdb->prepare(
        "SELECT * FROM " . GL_TABLE_LINKS . " WHERE slug_id = %d AND clicks < max_clicks ORDER BY id ASC LIMIT 1",
        $slug->id
    ));

    // 3. Se um link ativo for encontrado, redireciona
    if ($active_link) {
        // Incrementa o clique
        $wpdb->update(
            GL_TABLE_LINKS,
            ['clicks' => $active_link->clicks + 1],
            ['id' => $active_link->id]
        );

        // Redireciona
        wp_redirect($active_link->url, 302);
        exit;
    } 
    // 4. Se não houver link ativo, usa o fallback do slug
    else {
        if ($slug->fallback_page_id > 0 && get_post_status($slug->fallback_page_id) === 'publish') {
            wp_redirect(get_permalink($slug->fallback_page_id), 302);
            exit;
        } else {
            // Se não houver fallback, exibe uma mensagem de erro
            wp_die(
                'Desculpe, todos os links para este destino foram esgotados e não há uma página de fallback configurada.', 
                'Links Esgotados', 
                ['response' => 404]
            );
        }
    }
});